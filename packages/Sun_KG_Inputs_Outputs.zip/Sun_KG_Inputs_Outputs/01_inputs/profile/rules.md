Profile-Version: silica-six-class-relations-0.1-draft
# Silica research: six-category relation extraction adapter
Status: converted development draft, pending domain confirmation and real model testing.
Source: Ontology Keyword Selection Rules supplied on 2026-10-21.

## Task and boundaries
Extract only source-supported relations from the evidence regions supplied in the current request. Return the required JSON with no tools and no external knowledge. The profile covers silica fume, silica surfaces, and silicate-mineral dissolution studies; read each paper's own materials, methods, media, and scope.
This is a relation-only adapter, not a structured numerical-measurement profile and not a PDF highlighting task. Never inherit Wang-specific Table 1-3 tasks, 120 min, zero-order assumptions, GLDA conditions, or a 42-cell numerical quota into another paper.
Return kind=relation, a non-null subject and object, quantity=null, and only a predicate listed in vocabulary.predicates. Do not emit old Wang predicates. A supported standalone concept with no supported relation is not representable as a candidate in this adapter; do not invent an edge to retain it.
When there are no target relations in a request, return {"claims":[]}. A provider failure is not an empty scientific result.

## Six concept categories
Material: retain specific mineral, material, and sample names and distinguishing modifiers, including amorphous versus crystalline silica and USF versus DSF-1 versus DSF-2. Exclude generic materials, particles, unrelated container materials, and surface alone. A specifically identified silica or mineral surface can remain part of the complete Material phrase; do not add a seventh Surface category. This adapter does not solve cross-document sample identity.
ChemicalSubstance: identifiable chemicals involved in reactions or solution preparation. Exclude isolated Si, Al, Na, OH tokens as standalone selected chemicals, and do not split a complete formula into nested chemical entities. Context needed to understand a relation must still be preserved in statement and evidence.
Solvent: named media such as KOH solution, sodium hydroxide solution, GLDA solution, and Milli-Q water. This is the source annotation category for media; it does not claim the solute is itself a solvent. Exclude an unspecified solution or water as a standalone selected endpoint.
Process: a specific process or mechanism, including stepwise dissolution, congruent dissolution, hydroxylation, ligand complexation, and reactive molecular dynamics simulations. Generic reaction or process alone is insufficient. Simulations belong here rather than Experiment.
Experiment: a named physical experiment or laboratory characterization method, such as batch dissolution experiments, conductivity measurements, or X-ray photoelectron spectroscopy. Equipment brands and generic analysis are insufficient.
Property: a specific physicochemical property phrase, such as dissolution rate, specific surface area, activation energy, or dissolution factor. Generic rate, concentration, and temperature alone are insufficient. Keep explicit pH and other contextual values as conditions, not intrinsic material-property edges.
Use the shortest complete endpoint name while preserving scientifically distinguishing modifiers. Do not emit nested shorter duplicates at the same occurrence. Do not invent aliases, assume acid/salt identity, or merge USF, DSF-1, DSF-2 or amorphous/crystalline materials.

## Relations
Use dissolvesIn only for Material or ChemicalSubstance -> named Solvent, supported by local text establishing both endpoints and the dissolution context. A mention of dissolution rate or acceleration alone is insufficient. Passive voice is acceptable.
Use hasProperty only when both the described object/process and its specific property are identifiable. Numerical values, uncertainties and units remain in the evidence text and may be preserved verbatim in a concise statement; never populate a quantity object or invent a normalized number.
Use usedInProcess only for an identifiable Material, ChemicalSubstance, or Solvent -> a specific Process or Experiment. The methodological phrase using a model alone is insufficient.
The fourth source relation, reportedBy, is retained in vocabulary.deferred_relations but is NOT an allowed candidate predicate. Do not recast an author, document, or claim as Property merely to force it through this six-category record. Keep the existing source-span references and document provenance. This preserves traceability but does not implement the reportedBy relation.
Do not force all relation types to occur and do not emit an edge simply because a predicate exists.

## Scientific context and knowledge status
Every claim needs a study_context condition with raw equal to simulation, physical_experiment, or uncertain, value=null, unit=null, and state found or uncertain as supported by the supplied evidence. This is a controlled classification, not a verbatim quotation. If the context cannot be determined locally, use uncertain and record the missing context in issues. The existing validator does not independently certify this scientific classification.
For a directly reported simulation output use knowledge_type=reported_observation, an explicitly simulation-scoped statement, an appropriate simulation method, and study_context=simulation. Here reported_observation describes a reported output, not a physical laboratory observation. There is no separate simulation-result knowledge type in this adapter.
For a directly reported physical observation use reported_observation with physical_experiment context. Use author_interpretation for the authors' explanation of a result. Use proposed_mechanism with modality=proposed or uncertain for hypotheses and proposed mechanisms, whether in an experimental or simulation study.
Preserve negation, comparisons, qualifications and the material scope. An explicitly asserted author interpretation is not an independently proven scientific fact. Do not generalize an olivine mechanism to all silicates.
Preserve temperature, medium, pH, duration, material scope, and comparisons when supported and relevant. Additional condition raw values can retain original text, including printed numbers and units, but condition value must remain null in this relation-only adapter. Never import conditions from another paper or unrelated experimental/simulation setup.

## Evidence, provenance, and coverage
Use only source_span_id values supplied in this request and explain what each evidence span supports. Do not fabricate quotes, source locations, or identifiers. Include local qualifiers and relevant method/context evidence when available. An unresolved chunk boundary is a limitation to record, not permission to invent context.
Exclude references, acknowledgments, funding, download notices, running headers/footers and claims merely cited as background. Some generic parser regions still contain such text, so role=body alone does not make it an own-study finding. Do not emit knowledge_type=background; the current validator rejects it.
Do not read curve pixels or image-only text, estimate plotted values, or claim OCR was performed. Numeric values not selected as structured fields remain in the saved evidence text; this is not an assertion of complete numerical coverage.
The source red/blue colors, overlap priorities, per-page quotas, twice-per-term limits, and once-per-relation-pattern limits are reading-display policies. Do not apply them as KG deletion or extraction quotas. New conditions or new source-supported information are not duplicates merely because an endpoint name repeats.
Remove an exact repeated assertion only when its meaning, endpoints, context, and modality are the same. Preserve accessible supporting evidence; do not treat mention suppression as evidence deletion. Cross-chunk deduplication and evidence consolidation still need technical review.
The runtime assigns review and publication states. Never claim human acceptance, scientific verification, or formal publication. All output remains a development candidate pending domain review.
