SUN 2023 - INPUTS, MODEL CALLS, AND OUTPUTS

READING ORDER
1. 01_inputs/: unchanged original paper PDF and the three frozen profile files
   actually used in run 20261021T204207Z-ui.
2. 02_outputs/run.json: final succeeded / complete execution metadata.
3. 02_outputs/document.json and coverage.json: parsed evidence and final coverage.
4. task-index.json and 03_model_calls/: all 9 actual body extraction tasks.
   request.json = structured model input; prompt.txt = sent prompt;
   response.schema.json = response constraint; answer.json = original model
   output; execution.json = call completion; validation.json = per-task checks.
5. 02_outputs/candidates.raw.json and candidates.validated.json: 109 original
   relation candidates and their recorded engineering validation.
6. 02_outputs/graph.json and graph-result.json: intermediate snapshot and
   graph write result. The graph projection is viewable in the separate viewer.

IMPORTANT READING NOTES
All 109 candidates retain pending / demo_only. Validated means processed by
the current validator, not scientifically approved. The 101 simulation-context
records and 8 uncertain-context records must be interpreted with their scope.
The profile is silica-six-class-relations-0.1-draft.

Historical absolute USB paths and successful-call directory pointers remain
unchanged. Use source-mapping.json and task-index.json to find files here;
those historical pointers are not portable links or commands to execute.
graph.json retains an intermediate running state and initial coverage.
Final status/coverage are in run.json and coverage.json.
graph-result.json retains the old wang-demo namespace; it belongs to this
Sun run by run ID and document fingerprint. The parser inherited a Wang GLDA
limitation in document.json; it does not describe Sun's study.

This is an evidence and I/O archive, not a copy of the executable extraction
system. It excludes model login state, database credentials, caches, full
provider event streams, and system installation files. Included original
data files are byte-preserved; no new extraction or review was performed.
manifest.json and source-mapping.json record integrity and relocated paths.
