from pathlib import Path
import time, shutil, traceback, json, os, fcntl
from .config import ROOT, SOURCE, digest, save, read, setup_env
from .profiles import load_profile
from .parse import parse_document, table3_audit
from .providers import get_provider,provider_identity
from .validate import validate_payload,compare_table3

PIPELINE_VERSION="0.1.0"

def create_tasks(document,provider="codex"):
    tables={s['table_number']:s for s in document['spans'] if s['kind']=='table'}
    body=[s for s in document['spans'] if s['role']=='body']
    if all(x in tables for x in (1,2,3)) and document['document_id']=='doi:10.2138/am-2023-9025':
        methods=[s for s in body if s['page'] in (2,3)]
        tasks = [
          {'name':'measurements','instruction':'Extract ONLY all 42 Table 3 entries: 28 rates and 14 enhancement factors, matching exact printed rows and columns. Use the experimental method context for conditions. Do not extract other values.','spans':[tables[3]]+methods},
          {'name':'taxonomy','instruction':'Extract ONLY seven Table 1 mineral classifications and seven Q values (including the hornblende range), plus characterization methods if explicit. No composition or rates.','spans':[tables[1]]+[s for s in methods if s['page']==2]},
          {'name':'composition','instruction':'Extract ONLY every oxide mass% cell in the UPPER Table 2 block for the seven minerals. Each oxide/mineral pair is one measurement. Include N.D. as null/below_detection. Do not extract Total or normalized cations.','spans':[tables[2]]},
          {'name':'narrative','instruction':'Extract ONLY qualitative experimental observations, author interpretations, and proposed mechanisms. Select at most 30 central source-supported claims, prioritizing the olivine surface observations and the proposed GLDA mechanism. Keep each statement concise. Preserve material scope, lack of correlation and uncertainty. Do not repeat methods already extracted, numerical measurements, taxonomy, composition or generic background. Do not infer from image pixels, references or outside knowledge.','spans':body},
        ]
        if provider=="vllm":
            split=[]
            minerals=list(dict.fromkeys(x['mineral'] for x in table3_audit(document)))
            for task in tasks:
                if task['name'] in ('measurements','composition'):
                    for mineral in minerals:
                        split.append(dict(task,name=task['name']+'-'+mineral.lower(),instruction=task['instruction']+' In this call extract ONLY the mineral '+mineral+'.'))
                elif task['name']=='narrative':
                    for i in range(0,len(body),5): split.append(dict(task,name='narrative-'+str(i//5),spans=body[i:i+5]))
                else: split.append(task)
            return split
        return tasks
    tasks=[]
    for i in range(0,len(body),6): tasks.append({'name':f'body-{i//6:03d}','instruction':'Extract this profile\'s target claims from these evidence regions.','spans':body[i:i+6]})
    return tasks

def ingest(pdf,profile,provider='codex',force=False,run_id=None):
    setup_env()
    profile=load_profile(profile) if not isinstance(profile,dict) else profile
    document=parse_document(pdf)
    identity=provider_identity(provider)
    task_key=digest([document['sha256'],document['parser_id'],profile['fingerprint'],identity,PIPELINE_VERSION])
    if not force:
        existing=[]
        for path in (ROOT/'runs').glob('*/run.json'):
            record=read(path)
            if record.get('task_key')==task_key and record.get('status')=='succeeded': existing.append((record.get('completed_at',0),path.parent))
        if existing: return max(existing,key=lambda x:x[0])[1].name
    run_id=run_id or time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'-'+task_key[:8]
    directory=ROOT/'runs'/run_id; directory.mkdir(parents=True,exist_ok=True)
    lock=(directory/'run.lock').open('a')
    try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError: raise RuntimeError('This run is still active.')
    if (directory/'run.json').exists(): save(directory/'history'/f'run-{time.time_ns()}.json',read(directory/'run.json'))
    record={'run_id':run_id,'task_key':task_key,'status':'running','stage':'parse','provider':provider,'provider_identity':identity,'document_sha256':document['sha256'],'document_id':document['document_id'],'parser_id':document['parser_id'],'profile_version':profile['version'],'profile_fingerprint':profile['fingerprint'],'pipeline_version':PIPELINE_VERSION,'started_at':time.time(),'review_status':'pending','publication_status':'demo_only'}
    save(directory/'run.json',record); save(directory/'document.json',document)
    profile_dir=directory/'profile'; profile_dir.mkdir(exist_ok=True)
    for name in ('rules.md','vocabulary.json','output.schema.json','ontology.md'):
        origin=Path(profile['path'])/name
        if origin.exists(): shutil.copyfile(origin,profile_dir/name)
    coverage={x['source_span_id']:dict(x) for x in document['coverage']}
    tasks=create_tasks(document,provider); provider_impl=get_provider(provider); raw_claims=[]; validated=[]
    try:
        for index,task in enumerate(tasks):
            record.update(stage=task['name'],task_index=index,task_count=len(tasks)); save(directory/'run.json',record)
            taskdir=directory/task['name']; taskdir.mkdir(exist_ok=True)
            request={'task':task['instruction'],'ontology_version':profile['version'],'rules':profile['rules'],'vocabulary':profile['vocabulary'],'output_schema':profile['schema'],'evidence':[{'source_span_id':s['source_span_id'],'page':s['page'],'kind':s['kind'],'table_number':s.get('table_number'),'text':s['text']} for s in task['spans']]}
            # Reuse only complete saved calls with the exact same request; retries use a new attempt directory.
            request_hash=digest(request)
            cache=taskdir/'successful-call.json'
            if cache.exists() and read(cache).get('request_hash')==request_hash:
                payload=read(Path(read(cache)['directory'])/'answer.json')
            else:
                attempt=taskdir/f'attempt-{len(list(taskdir.glob("attempt-*")))+1:02d}'
                payload=provider_impl.extract(request,profile['schema'],attempt)
                save(cache,{'request_hash':request_hash,'directory':str(attempt)})
            result=validate_payload(payload,profile,document,{s['source_span_id'] for s in task['spans']})
            save(taskdir/'validation.json',result)
            if not result['schema_valid']: raise RuntimeError(f"{task['name']}: schema validation failed: {result['errors'][:3]}")
            raw_claims.extend(payload['claims']); validated.extend(result['claims'])
            for span in task['spans']: coverage[span['source_span_id']].update(state='completed',reason='checked by '+task['name'])
            save(directory/'coverage.json',list(coverage.values()))
            save(directory/'candidates.raw.json',{'claims':raw_claims})
            unique={c['claim_id']:c for c in validated}; save(directory/'candidates.validated.json',list(unique.values()))
        unique={c['claim_id']:c for c in validated}; validated=list(unique.values())
        # Record every span, including native chart text not used as numerical evidence.
        for entry in coverage.values():
            if entry['state']=='pending': entry.update(state='excluded',reason='duplicate native table text or image/plot-only region; represented by table evidence where applicable')
        save(directory/'coverage.json',list(coverage.values()))
        audit=None
        if document['document_id']=='doi:10.2138/am-2023-9025':
            audit=compare_table3([c for c in validated if c['demo_eligible']],table3_audit(document),profile['vocabulary']); save(directory/'table3-audit.json',audit)
            if not audit['all_passed']: raise RuntimeError(f"Table 3 audit: {audit['passed']}/42 passed; original outputs preserved; graph not replaced")
        eligible=[c for c in validated if c['demo_eligible']]
        if not eligible: raise RuntimeError('No candidate passed engineering validation; no demo graph was created.')
        record.update(stage='graph',candidate_count=len(validated),eligible_count=len(eligible),blocked_count=len(validated)-len(eligible)); save(directory/'run.json',record)
        from .graph import publish_demo
        result=publish_demo(document,eligible,record)
        save(directory/'graph-result.json',result)
        save(directory/'graph.json',{'document':document,'claims':eligible,'run':record})
        record.update(status='succeeded',stage='complete',completed_at=time.time(),table3_passed=audit['passed'] if audit else None)
        save(directory/'run.json',record)
        save(ROOT/'data/latest.json',{'run_id':run_id,'document_sha256':document['sha256']})
        return run_id
    except Exception as e:
        record.update(status='failed',error=str(e),failed_at=time.time()); save(directory/'run.json',record)
        (directory/'traceback.log').write_text(traceback.format_exc())
        for entry in coverage.values():
            if entry['state']=='pending': entry.update(state='failed',reason=str(e))
        save(directory/'coverage.json',list(coverage.values()))
        raise
    finally:
        fcntl.flock(lock,fcntl.LOCK_UN); lock.close()
