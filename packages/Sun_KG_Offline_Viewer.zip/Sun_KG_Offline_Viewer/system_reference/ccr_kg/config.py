from pathlib import Path
import os, json, hashlib, tempfile, platform

ROOT = Path(os.environ.get("CCR_KG_ROOT", Path(__file__).resolve().parents[2]))
SOURCE = Path(__file__).resolve().parents[1]

def guard():
    if platform.system() == "Darwin" and not ROOT.is_mount():
        raise RuntimeError(f"USB APFS working volume is not mounted: {ROOT}. Internal-disk fallback is prohibited.")
    if not (ROOT / "runtime").is_dir():
        raise RuntimeError("The configured runtime directory is missing.")
    import shutil
    if shutil.disk_usage(ROOT).free < 256 * 1024**2:
        raise RuntimeError("The working volume has less than 256 MiB free.")

def setup_env():
    guard()
    for key, suffix in {"TMPDIR":"tmp", "UV_CACHE_DIR":"cache/uv", "PIP_CACHE_DIR":"cache/pip", "XDG_CACHE_HOME":"cache", "PYTHONPYCACHEPREFIX":"cache/pycache", "PLAYWRIGHT_BROWSERS_PATH":"cache/browsers"}.items():
        p=ROOT/suffix; p.mkdir(parents=True,exist_ok=True); os.environ[key]=str(p)
    tempfile.tempdir=str(ROOT/"tmp")

def digest(value):
    if not isinstance(value,bytes):
        value=json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(",",":")).encode()
    return hashlib.sha256(value).hexdigest()

def save(path, value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+".tmp")
    temp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding="utf-8")
    os.replace(temp,path)

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def db_config():
    return read(ROOT/"runtime"/"database.json")
