import json,time
from pathlib import Path
from neo4j import GraphDatabase
from .config import ROOT,digest,db_config,save,read
from .validate import canonical

class GraphStore:
    def __init__(self,config=None):
        self.config=config or db_config()
        self.driver=GraphDatabase.driver(self.config['uri'],auth=(self.config['user'],self.config['password']),connection_timeout=5,connection_acquisition_timeout=8,max_transaction_retry_time=5,notifications_min_severity="OFF")
    def __enter__(self): return self
    def __exit__(self,*_): self.driver.close()
    def health(self): self.driver.verify_connectivity(); return True
    def query(self,query,**params):
        with self.driver.session() as session: return session.run(query,**params).data()
    def schema(self):
        self.query('CREATE CONSTRAINT ccr_kg_id IF NOT EXISTS FOR (n:CCRKG) REQUIRE n.id IS UNIQUE')
    def counts(self):
        return self.query('MATCH (n:CCRKG) RETURN count(n) AS nodes')[0] | self.query('MATCH (:CCRKG)-[r]->(:CCRKG) RETURN count(r) AS relationships')[0]
    def releases(self):
        return self.query('MATCH (r:CCRKG:Release) WHERE NOT r.namespace STARTS WITH "test-" OPTIONAL MATCH (s:CCRKG:GraphSpace)-[:ACTIVE]->(r) RETURN coalesce(r.document_id,s.document_id) AS document_id,r.run_id AS run_id,r.id AS release_id,s IS NOT NULL AS current ORDER BY r.created_at DESC')
    def claims(self,run_id=None,published_only=False):
        if run_id:
            query='MATCH (r:CCRKG:Release {run_id:$run})-[:INCLUDES]->(c:CCRKG:Claim) WHERE c.review_status <> "rejected"'
        else:
            query='MATCH (:CCRKG:GraphSpace)-[:ACTIVE]->(r:CCRKG:Release)-[:INCLUDES]->(c:CCRKG:Claim) WHERE NOT r.namespace STARTS WITH "test-" AND c.review_status <> "rejected"'
        if published_only: query+=' AND c.publication_status="published"'
        rows=self.query(query+' RETURN DISTINCT c.payload AS payload,c.review_status AS review,c.publication_status AS publication',run=run_id)
        values=[]
        for r in rows:
            c=json.loads(r['payload']); c['review_status']=r['review']; c['publication_status']=r['publication']; values.append(c)
        return values


    def neighbors(self,entity,run_id):
        rows=self.query('MATCH (:CCRKG:Release {run_id:$run})-[:INCLUDES]->(c:CCRKG:Claim)-[:ABOUT]->(s:CCRKG:Entity) OPTIONAL MATCH (c)-[:OBJECT]->(o:CCRKG:Entity) WITH c,s,o WHERE c.review_status <> "rejected" AND (s.id=$entity OR o.id=$entity) RETURN DISTINCT c.payload AS payload,c.review_status AS review,c.publication_status AS publication',run=run_id,entity=entity)
        result=[]
        for row in rows:
            c=json.loads(row['payload']);c['review_status']=row['review'];c['publication_status']=row['publication'];result.append(c)
        return result
    def evidence(self,span_id,run_id):
        return self.query('MATCH (:CCRKG:Release {run_id:$run})-[:INCLUDES]->(:CCRKG:Claim)-[:SUPPORTED_BY]->(e:CCRKG:Evidence {source_span_id:$span})-[:SOURCE]->(d:CCRKG:Document) RETURN DISTINCT e.source_span_id AS source_span_id,e.page AS page,e.text AS text,e.bbox AS bbox,e.parser_id AS parser_id,d.sha256 AS document_sha256,d.pdf AS pdf',run=run_id,span=span_id)

def entity_id(entity,document):
    name=entity['name'].strip().lower()
    scope=document['sha256'] if entity['entity_type']=='Sample' else 'canonical'
    return 'entity:'+digest([scope,entity['entity_type'],name])[:28]

def publish_demo(document,claims,run,namespace='wang-demo',fail_before_switch=False):
    """Single transaction stages release and switches pointer; failure retains old graph."""
    with GraphStore() as store:
        store.schema()
        def write(tx):
            doc_id='document:'+document['sha256']; release_id='release:'+namespace+':'+run['run_id']; space_id='space:'+namespace+':'+document['document_id']
            tx.run('MERGE (d:CCRKG:Document {id:$id}) SET d.sha256=$sha,d.document_id=$doc,d.pdf=$pdf,d.parser_id=$parser',id=doc_id,sha=document['sha256'],doc=document['document_id'],pdf=document['pdf'],parser=document['parser_id']).consume()
            tx.run('MERGE (r:CCRKG:Release {id:$id}) ON CREATE SET r.created_at=$now SET r.run_id=$run,r.namespace=$ns,r.status="demo",r.document_id=$doc',id=release_id,run=run['run_id'],now=time.time(),ns=namespace,doc=document['document_id']).consume()
            provenance_run='run:'+namespace+':'+run['run_id']
            provenance={k:run.get(k) for k in ('run_id','provider','provider_identity','task_key','profile_version','profile_fingerprint','pipeline_version','parser_id')}
            tx.run('MERGE (r:CCRKG:Run {id:$id}) SET r.run_id=$run,r.metadata=$metadata,r.artifact_path=$path',id=provenance_run,run=run['run_id'],metadata=json.dumps(provenance),path='runs/'+run['run_id']).consume()
            for c in claims:
                if not c.get('demo_eligible'): raise ValueError('Blocked claim cannot enter demo graph')
                sid=entity_id(c['subject'],document)
                tx.run('MERGE (s:CCRKG:Entity {id:$id}) SET s.name=$name,s.entity_type=$type',id=sid,name=c['subject']['name'],type=c['subject']['entity_type']).consume()
                if c['subject']['entity_type']=='Sample':
                    mineral_id=entity_id({'name':c['subject']['name'],'entity_type':'Mineral'},document)
                    tx.run('MERGE (m:CCRKG:Entity {id:$mid}) SET m.name=$name,m.entity_type="Mineral" WITH m MATCH (s:CCRKG {id:$sid}) MERGE (s)-[:INSTANCE_OF]->(m)',mid=mineral_id,name=c['subject']['name'],sid=sid).consume()
                cid=namespace+':'+c['claim_id']
                provenance={k:run.get(k) for k in ('run_id','provider','provider_identity','task_key','profile_version','profile_fingerprint','pipeline_version','parser_id')}
                tx.run('MERGE (c:CCRKG:Claim {id:$id}) ON CREATE SET c.review_status="pending",c.publication_status="demo_only",c.payload=$payload,c.provenance=$prov SET c.claim_id=$claim,c.knowledge_type=$kind,c.modality=$modality WITH c MATCH (s:CCRKG {id:$sid}),(r:CCRKG {id:$release}) MERGE (r)-[:INCLUDES]->(c) MERGE (c)-[:ABOUT]->(s)',id=cid,claim=c['claim_id'],payload=json.dumps(c,ensure_ascii=False),prov=json.dumps(provenance),kind=c['knowledge_type'],modality=c['modality'],sid=sid,release=release_id).consume()
                tx.run('MATCH (c:CCRKG:Claim {id:$cid}),(r:CCRKG:Run {id:$rid}) MERGE (c)-[:EXTRACTED_IN]->(r)',cid=cid,rid=provenance_run).consume()
                if c['object']:
                    oid=entity_id(c['object'],document)
                    tx.run('MERGE (o:CCRKG:Entity {id:$oid}) SET o.name=$name,o.entity_type=$type WITH o MATCH (s:CCRKG {id:$sid}),(c:CCRKG {id:$cid}) MERGE (s)-[r:RELATED {claim_id:$cid}]->(o) SET r.predicate=$predicate,r.modality=$modality MERGE (c)-[:OBJECT]->(o)',oid=oid,name=c['object']['name'],type=c['object']['entity_type'],sid=sid,cid=cid,predicate=c['predicate'],modality=c['modality']).consume()
                else:
                    mid=cid+':measurement'
                    tx.run('MERGE (m:CCRKG:Measurement {id:$mid}) SET m.payload=$payload,m.value=$value,m.unit=$unit,m.name=$name WITH m MATCH (s:CCRKG {id:$sid}),(c:CCRKG {id:$cid}) MERGE (s)-[:HAS_MEASUREMENT {claim_id:$cid}]->(m) MERGE (c)-[:RESULT]->(m)',mid=mid,payload=json.dumps(c['quantity'],ensure_ascii=False),value=c['quantity']['value'],unit=c['quantity']['unit'],name=c['quantity']['name'],sid=sid,cid=cid).consume()
                for i,condition in enumerate(c['conditions']):
                    tx.run('MERGE (n:CCRKG:Condition {id:$id}) SET n.payload=$payload,n.kind=$kind,n.value=$value,n.raw=$raw WITH n MATCH (c:CCRKG {id:$cid}) MERGE (c)-[:UNDER_CONDITION]->(n)',id=cid+':condition:'+str(i),payload=json.dumps(condition,ensure_ascii=False),kind=condition['kind'],value=condition['value'],raw=condition['raw'],cid=cid).consume()
                for evidence in c['evidence_records']:
                    eid='evidence:'+evidence['source_span_id']
                    tx.run('MERGE (e:CCRKG:Evidence {id:$id}) SET e.source_span_id=$span,e.page=$page,e.text=$text,e.bbox=$bbox,e.parser_id=$parser WITH e MATCH (d:CCRKG {id:$doc}),(c:CCRKG {id:$cid}) MERGE (c)-[:SUPPORTED_BY]->(e) MERGE (e)-[:SOURCE]->(d)',id=eid,span=evidence['source_span_id'],page=evidence['page'],text=evidence['text'],bbox=evidence['bbox'],parser=evidence['parser_id'],doc=doc_id,cid=cid).consume()
            if fail_before_switch: raise RuntimeError('Synthetic update failure, rollback required')
            tx.run('MERGE (s:CCRKG:GraphSpace {id:$space}) SET s.document_id=$doc WITH s OPTIONAL MATCH (s)-[old:ACTIVE]->(:CCRKG:Release) DELETE old WITH DISTINCT s MATCH (r:CCRKG:Release {id:$release}) MERGE (s)-[:ACTIVE]->(r)',space=space_id,doc=document['document_id'],release=release_id).consume()
            return {'release_id':release_id,'claim_count':len(claims),'namespace':namespace,'formal_publication':False}
        with store.driver.session() as session: return session.execute_write(write)

def review_claim(run_id,claim_id,decision,reviewer,note=''):
    if decision not in ('accepted','rejected','deferred') or not reviewer.strip(): raise ValueError('A valid review decision and actual reviewer name are required.')
    run=ROOT/'runs'/run_id
    candidate=next(c for c in read(run/'candidates.validated.json') if c['claim_id']==claim_id)
    if decision=='accepted' and not candidate['demo_eligible']: raise ValueError('This candidate failed a blocking engineering check and cannot be accepted.')
    value={'claim_id':claim_id,'decision':decision,'reviewer':reviewer.strip(),'note':note,'time':time.time(),'candidate':candidate,'db_synced':False}
    target=run/'reviews'/f'{claim_id.replace(":","_")}.json'
    if target.exists(): save(run/'reviews'/'history'/f'{target.stem}-{time.time_ns()}.json',read(target))
    save(target,value)
    with GraphStore() as store:
        store.query('MATCH (:CCRKG:Release {run_id:$run})-[:INCLUDES]->(c:CCRKG:Claim {claim_id:$id}) SET c.review_status=$decision,c.reviewer=$reviewer,c.reviewed_at=$now,c.publication_status=CASE WHEN $decision="rejected" AND c.publication_status="published" THEN "withdrawn" ELSE c.publication_status END',run=run_id,id=claim_id,decision=decision,reviewer=reviewer.strip(),now=value['time'])
    value['db_synced']=True; save(target,value); return value

def publish_accepted(run_id):
    root=ROOT/'runs'/run_id
    accepted=[read(p) for p in (root/'reviews').glob('*.json') if read(p)['decision']=='accepted']
    if not accepted: raise ValueError('There are no human-accepted records.')
    for r in accepted:
        if not r['candidate']['demo_eligible']: raise ValueError('Candidates that failed validation cannot be published.')
    with GraphStore() as store:
        def write(tx):
            for r in accepted:
                result=tx.run('MATCH (:CCRKG:Release {run_id:$run})-[:INCLUDES]->(c:CCRKG:Claim {claim_id:$id}) WHERE coalesce(c.reviewed_at,0)<=$approved SET c.review_status="accepted",c.reviewer=$reviewer,c.reviewed_at=$approved,c.publication_status="published",c.published_at=$now RETURN count(c) AS count',run=run_id,id=r['claim_id'],approved=r['time'],reviewer=r['reviewer'],now=time.time()).single()
                if result['count']!=1: raise ValueError('Publication requires exactly one matching reviewed candidate.')
        with store.driver.session() as session: session.execute_write(write)
    save(root/'publication.json',{'claim_ids':[r['claim_id'] for r in accepted],'published_at':time.time()})
    return len(accepted)

def graph_elements(claims,document,mode='overview'):
    nodes={}; edges=[]; bridges=set()
    mineral_names={c['subject']['name'].lower() for c in claims if c['subject']['entity_type']=='Mineral'}
    def node(entity):
        id=entity_id(entity,document)
        nodes[id]={'data':{'id':id,'label':entity['name']+(' (paper sample)' if entity['entity_type']=='Sample' else ''),'type':entity['entity_type']}}
        return id
    for c in claims:
        if mode=='overview' and c['kind']=='measurement': continue
        if mode=='experiments' and c['predicate'] not in ('hasDissolutionRate','hasEnhancementFactor'): continue
        sid=node(c['subject'])
        if mode!='experiments' and c['subject']['entity_type']=='Sample' and c['subject']['name'].lower() in mineral_names and sid not in bridges:
            mid=node({'name':c['subject']['name'],'entity_type':'Mineral'});bridges.add(sid)
            edges.append({'data':{'id':'instance:'+sid,'source':sid,'target':mid,'label':'sample of','claim_id':c['claim_id'],'proposed':False,'modality':'asserted'}})
        labels={'hasDissolutionRate':'dissolution rate','hasEnhancementFactor':'enhancement factor','hasComposition':'mass composition','hasConnectivity':'Q','belongsTo':'belongs to','contains':'contains','enhances':'enhances','adsorbsOn':'adsorbs on','forms':'forms','attracts':'attracts','polarizes':'polarizes','promotes':'promotes','hasObservation':'observed','characterizedBy':'characterized by'}
        if c['object']: oid=node(c['object']); label=c['predicate']
        else:
            q=c['quantity']; oid=c['claim_id']; label=c['predicate']
            val=q['raw']; nodes[oid]={'data':{'id':oid,'label':f"{q['name']}: {val}",'type':'Measurement','claim_id':c['claim_id']}}
        edges.append({'data':{'id':'edge:'+c['claim_id'],'source':sid,'target':oid,'label':('not observed' if c['modality']=='negated' and label=='hasObservation' else 'negated: '+labels.get(label,label) if c['modality']=='negated' else labels.get(label,label)),'claim_id':c['claim_id'],'proposed':c['knowledge_type'] in ('proposed_mechanism','author_interpretation'),'modality':c['modality']}})
    return list(nodes.values())+edges
