"""Native PDF extraction; every quote comes from a persisted text region."""
from pathlib import Path
import re, shutil, importlib.metadata
import pdfplumber
from .config import ROOT, digest, save, read
PARSER_VERSION="pdfplumber-columns-v2"

def parse_document(pdf_path):
    pdf_path=Path(pdf_path); raw=pdf_path.read_bytes(); sha=digest(raw)
    directory=ROOT/"data"/"documents"/sha; directory.mkdir(parents=True,exist_ok=True)
    stored=directory/"source.pdf"
    if not stored.exists(): shutil.copyfile(pdf_path,stored)
    parser_id=digest([PARSER_VERSION,importlib.metadata.version("pdfplumber")])[:16]
    cache=directory/f"parse-{parser_id}.json"
    if cache.exists():
        cached=read(cache); cached["pdf"]=str(stored); return cached
    spans=[]; pages=[]; coverage=[]
    with pdfplumber.open(stored) as doc:
        identity_text=re.sub(r"\s+","",doc.pages[0].extract_text() or "").lower() if doc.pages else ""
        known_wang="10.2138/am-2023-9025" in identity_text
        for number,page in enumerate(doc.pages,1):
            regions=[]
            for col,(x0,x1) in enumerate(((28,page.width/2),(page.width/2,page.width-25)),1):
                crop=page.crop((x0,35,x1,page.height-28))
                text=crop.extract_text(x_tolerance=2,y_tolerance=3) or ""
                lines=text.splitlines(keepends=True)
                start=0; chunk=""; top=35
                # Chunk on line boundaries; retain exact offsets in each region string.
                for line in lines+[""]:
                    if chunk and (len(chunk)+len(line)>1700 or line==""):
                        regions.append({"text":chunk,"bbox":[x0,35,x1,page.height-28],"column":col,"region_start":start,"region_text":text})
                        start+=len(chunk); chunk=""
                    chunk+=line
            page_text=""; source_offset=0
            for region in regions:
                text=region["text"]
                role="references" if (number==len(doc.pages) or "References cited" in text and text.index("References cited")<150) else "body"
                span_id="E-"+digest([sha,parser_id,number,region["column"],region["region_start"],text])[:20]
                record={"source_span_id":span_id,"document_version":sha,"parser_id":parser_id,"page":number,"bbox":region["bbox"],"column":region["column"],"start_char":source_offset,"end_char":source_offset+len(text),"text":text,"role":role,"kind":"text"}
                # Refine the vertical bounding box by matching characters in the native PDF region.
                chars=[c for c in page.chars if region["bbox"][0]<=c["x0"]<region["bbox"][2] and 35<=c["top"]<page.height-28]
                if chars:
                    first_line=text.splitlines()[0] if text.splitlines() else ""
                    words=page.crop(tuple(region["bbox"])).extract_words()
                    target=first_line.split()[:3]
                    matches=[w for w in words if target and w["text"]==target[0]]
                    if len(matches)==1: record["bbox"][1]=max(35,matches[0]["top"]-3)
                spans.append(record); page_text+=text+"\n"; source_offset+=len(text)+1
                coverage.append({"source_span_id":span_id,"page":number,"state":"excluded" if role=="references" else "pending","reason":"reference list, not this paper's results" if role=="references" else ""})
            pages.append({"page":number,"width":float(page.width),"height":float(page.height),"text":page_text})
        # Locate table titles from native words; table crops preserve exact extracted text.
        for table_no,page_no in ((1,2),(2,3),(3,4)):
            if page_no>len(doc.pages): continue
            page=doc.pages[page_no-1]
            matches=page.search(r"Table\s+"+str(table_no)+r"\.",regex=True)
            starts=[m for m in matches if m.get("chars") and abs(float(m["chars"][0]["size"])-8)<0.3]
            if not starts: continue
            title=starts[0]
            x0=page.width/2 if title["x0"]>page.width/2 else 28
            x1=page.width-25 if x0>28 else page.width/2
            top=max(35,title["top"]-3)
            if table_no==2: bottom=page.height*.53
            else: bottom=page.height-28
            text=page.crop((x0,top,x1,bottom)).extract_text(x_tolerance=2,y_tolerance=3) or ""
            span_id="E-"+digest([sha,parser_id,page_no,table_no,text])[:20]
            # Table source uses a separately persisted immutable region string, with offsets into that region.
            spans.append({"source_span_id":span_id,"document_version":sha,"parser_id":parser_id,"page":page_no,"bbox":[x0,top,x1,bottom],"column":1 if x0==28 else 2,"start_char":0,"end_char":len(text),"text":text,"role":"table","kind":"table","table_number":table_no,"offset_basis":"table-region-text"})
            coverage.append({"source_span_id":span_id,"page":page_no,"state":"pending","reason":""})
    result={"document_id":"doi:10.2138/am-2023-9025" if known_wang else "pdf:"+sha[:20],"sha256":sha,"parser_id":parser_id,"parser_version":PARSER_VERSION,"pdf":str(stored),"pages":pages,"spans":spans,"coverage":coverage,"limitations":["No curve digitization or image-only numerical extraction.","Native two-column order and table regions require visual QA.","Methods include a 1% GLDA sentence inconsistent with the main 2 wt% protocol; preserve ambiguity."]}
    save(cache,result); return result

def table3_audit(document):
    tables=[s for s in document["spans"] if s.get("table_number")==3]
    if len(tables)!=1: raise ValueError("Table 3 evidence missing")
    text=tables[0]["text"]
    pattern=r"\d+(?:\.\d+)?\s*[×x]\s*10\s*[−–-]\s*\d+|\d+(?:\.\d+)?"
    cells=[]
    for line in text.splitlines():
        if not re.match(r"^[A-Za-z]+\s+\d",line): continue
        mineral=line.split()[0]
        if mineral.lower()=="ph": continue
        tokens=re.findall(pattern,line[len(mineral):])
        if len(tokens)!=6: continue
        for i,token in enumerate(tokens):
            clean=re.sub(r"\s+","",token).replace("–","-").replace("−","-")
            value=float(re.sub(r"[×x]10", "e", clean))
            cells.append({"mineral":mineral,"predicate":"hasDissolutionRate" if i<4 else "hasEnhancementFactor","medium":"GLDA solution" if i<2 else "Milli-Q water" if i<4 else "GLDA / Milli-Q water","pH":4 if i%2==0 else 8,"value":value,"raw":token,"source_span_id":tables[0]["source_span_id"]})
    if len(cells)!=42: raise ValueError(f"Table 3 parsed {len(cells)} cells, expected 42; manual layout repair required")
    return cells

def render_evidence(document,span_id):
    from PIL import ImageDraw
    import pypdfium2 as pdfium
    span=next(s for s in document["spans"] if s["source_span_id"]==span_id)
    out=ROOT/"data"/"previews"/f"{span_id}.png"
    if out.exists(): return out
    out.parent.mkdir(parents=True,exist_ok=True)
    pdf=pdfium.PdfDocument(document["pdf"])
    image=pdf[span["page"]-1].render(scale=1.6).to_pil().convert("RGB")
    draw=ImageDraw.Draw(image); box=[v*1.6 for v in span["bbox"]]
    draw.rectangle(box,outline="#e65e35",width=4)
    image.save(out); pdf.close(); return out
