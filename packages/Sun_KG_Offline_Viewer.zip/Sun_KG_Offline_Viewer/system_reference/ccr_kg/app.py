from pathlib import Path
import json,os,subprocess,time
import streamlit as st
import pandas as pd
from ccr_kg.config import ROOT,SOURCE,setup_env,read,save
from ccr_kg.graph import GraphStore,graph_elements,entity_id,review_claim,publish_accepted
from ccr_kg.profiles import load_profile,upload_profile,NAMES
from ccr_kg.parse import render_evidence

setup_env()
(ROOT/"runtime/app.pid").write_text(str(os.getpid()))
st.set_page_config(page_title='CCR · Literature Knowledge Graph',page_icon='🔬',layout='wide')
st.markdown('<style>'+(SOURCE/'ccr_kg/assets/app.css').read_text()+'</style>',unsafe_allow_html=True)
st.caption('CCR RESEARCH WORKSPACE  /  LITERATURE → KNOWLEDGE')
st.title('Literature Knowledge Graph')
st.markdown('Wang 2024 · Silicate minerals and GLDA · **Development demo / Pending domain review**')

@st.cache_resource
def database(): return GraphStore()

@st.cache_resource
def graph_component(asset_version):
    assets=SOURCE/'ccr_kg/assets'
    return st.components.v2.component('ccr_kg_network',isolate_styles=False,js=(assets/'cytoscape.min.js').read_text()+'\n'+(assets/'graph_component.js').read_text())

db=database(); releases=[];claims=[];document=None;run_id=None
try:
    releases=[r for r in db.releases() if (ROOT/"runs"/r["run_id"]/"document.json").exists() and not r["run_id"].startswith("synthetic-")]
except Exception as error:
    st.error('Neo4j is unavailable. Run Start CCR.command on the USB drive. Existing evidence and candidates remain saved.')
    with st.expander('Connection details'): st.code(str(error))

with st.sidebar:
    st.markdown('### Research library')
    if releases:
        active=next((r for r in releases if r.get('current')),releases[0])['run_id']
        if st.session_state.get('last-active-release')!=active:
            st.session_state['chosen_run']=active;st.session_state['last-active-release']=active
        run_id=st.selectbox('Graph version',[r['run_id'] for r in releases],key='chosen_run')
        document=read(ROOT/'runs'/run_id/'document.json')
        claims=db.claims(run_id)
        scope=read(ROOT/'runs'/run_id/'run.json').get('scope')
        if scope: st.caption('Version scope: '+scope)
        st.caption('Wang et al. · American Mineralogist 109 · 2024')
    st.divider()
    st.markdown('### How to explore')
    st.write('Click a node or edge to inspect its records. Select a node to expand its neighbors. Dashed edges indicate author interpretations or proposed mechanisms.')
    st.caption('Graph browsing queries the database directly; it does not call the model.')
    st.caption('Storage: CCR disk image on the USB drive')
    if st.button('Refresh graph and run status',width='stretch'): st.rerun()

tabs=st.tabs(['Knowledge graph','Experimental data','Add / update','Human review','Run history'])

def detail(c,prefix):
    st.markdown('#### '+c['subject']['name'])
    st.write(c['statement'])
    types={'reported_measurement':'Reported quantitative record','reported_classification':'Reported classification','reported_observation':'Experimental observation','author_interpretation':'Author interpretation','proposed_mechanism':'Proposed mechanism','background':'Cited background'}
    modalities={'asserted':'Reported statement','proposed':'Proposed by the authors','uncertain':'Uncertain','negated':'Negated relation'}
    publications={'demo_only':'Development demo','published':'Published','blocked':'Validation failed','withdrawn':'Withdrawn'}
    st.caption(types.get(c['knowledge_type'],c['knowledge_type'])+' · '+modalities.get(c['modality'],c['modality'])+' · '+publications.get(c['publication_status'],c['publication_status']))
    if c['quantity']:
        q=c['quantity']; st.code(f"{q['name']} = {q['raw']}  [{q['unit']}]")
        st.caption(q['basis'])
    if c['conditions']: st.dataframe(pd.DataFrame(c['conditions']).rename(columns={'kind':'Condition','raw':'Source text','value':'Value','upper':'Upper bound','unit':'Unit','state':'Evidence status'}),hide_index=True,width='stretch')
    if c['method']: st.write('Method: '+c['method'])
    if c['issues']: st.warning('; '.join(c['issues']))
    refs=c['evidence_records']
    if refs:
        index=st.selectbox('Source evidence',range(len(refs)),format_func=lambda i:f"PDF page {refs[i]['page']} · {refs[i].get('kind','text')} · {refs[i]['source_span_id'][-8:]}",key=prefix+'-evidence')
        evidence=refs[index]
        with st.expander('View source text',expanded=True): st.text(evidence['text'])
        if st.checkbox('Show PDF page and evidence region',key=prefix+'-pdf'):
            st.image(str(render_evidence(document,evidence['source_span_id'])),caption=f"PDF page {evidence['page']}; orange box marks the registered evidence region",width='stretch')
        if st.button('Save source PDF to USB',key=prefix+'-save-pdf'):
            import shutil
            target=ROOT/'exports/Wang_original.pdf';shutil.copyfile(document['pdf'],target);st.success('Saved: '+str(target))

with tabs[0]:
    if claims:
        a,b,c,d=st.columns(4)
        a.metric('Traceable records',len(claims));b.metric('Dissolution rates',sum(x['predicate']=='hasDissolutionRate' for x in claims));c.metric('Enhancement factors',sum(x['predicate']=='hasEnhancementFactor' for x in claims));d.metric('Published records',sum(x['publication_status']=='published' for x in claims))
        left,right=st.columns([3,1.35])
        with left:
            f1,f2,f3=st.columns([2,1,1.5])
            view=f1.selectbox('View',['Relation overview','Dissolution experiments','All records'],index=0 if any(x['kind']=='relation' for x in claims) else 1)
            ph=f2.selectbox('pH',['All',4,8])
            medium=f3.selectbox('Medium',['All','GLDA solution','Milli-Q water','GLDA / Milli-Q water'])
            search=st.text_input('Search minerals, entities, or relations',placeholder='e.g. Olivine, GLDA, surface')
            selected_claims=[]
            for claim in claims:
                conditions=claim['conditions']; values={x['kind'].lower():x for x in conditions}
                if claim['kind']=='measurement' and ph!='All' and values.get('ph',{}).get('value')!=ph: continue
                if claim['kind']=='measurement' and medium!='All' and values.get('medium',{}).get('raw')!=medium: continue
                if search and search.lower() not in json.dumps([claim['subject'],claim['object'],claim['predicate'],claim['statement']],ensure_ascii=False).lower(): continue
                selected_claims.append(claim)
            mode={'Relation overview':'overview','Dissolution experiments':'experiments','All records':'all'}[view]
            elements=graph_elements(selected_claims,document,mode)
            allnodes={e['data']['id']:e for e in elements if 'source' not in e['data']}
            alledges=[e for e in elements if 'source' in e['data']]
            state_key=f'visible-{run_id}-{view}-{ph}-{medium}-{search}'
            if state_key not in st.session_state:
                roots={id for id,n in allnodes.items() if n['data']['type']=='Mineral' or n['data']['label'].upper()=='GLDA'}
                if mode!='overview' or not roots: visible=set(allnodes)
                else: visible=roots|{e['data'][side] for e in alledges for side in ('source','target') if e['data']['source'] in roots or e['data']['target'] in roots}
                st.session_state[state_key]=list(visible)
            visible=set(st.session_state[state_key])
            chosen=st.session_state.get('ccr-selected',{})
            tools=st.columns(3)
            if tools[0].button('Expand selected node',disabled=not chosen.get('id') or 'source' in chosen):
                id=chosen['id']; visible|={e['data'][side] for e in alledges for side in ('source','target') if id in (e['data']['source'],e['data']['target'])}
                st.session_state[state_key]=list(visible)
            if tools[1].button('Expand all'): visible=set(allnodes);st.session_state[state_key]=list(visible)
            fit=tools[2].button('Fit graph')
            shown=[n for id,n in allnodes.items() if id in visible]+[e for e in alledges if e['data']['source'] in visible and e['data']['target'] in visible]
            result=graph_component((SOURCE/'ccr_kg/assets/graph_component.js').stat().st_mtime)(data={'elements':shown,'fit':fit},key='network',default={'selected':{}},on_selected_change=lambda:None,on_expand_change=lambda:None,on_snapshot_change=lambda:None)
            if result.snapshot:
                import base64
                data=base64.b64decode(result.snapshot.split(',',1)[1],validate=True)
                if len(data)>20*1024**2: raise ValueError('Graph image exceeds 20 MiB')
                (ROOT/'exports/graph-preview.png').write_bytes(data)
                st.success('Graph PNG saved to USB: exports/graph-preview.png')
            if result.selected and result.selected!=st.session_state.get('ccr-selected'):
                st.session_state['ccr-selected']=dict(result.selected); st.rerun()
            if result.expand:
                id=result.expand; visible|={e['data'][side] for e in alledges for side in ('source','target') if id in (e['data']['source'],e['data']['target'])}; st.session_state[state_key]=list(visible); st.rerun()
            st.caption(f"Showing {sum('source' not in x['data'] for x in shown)} nodes / {sum('source' in x['data'] for x in shown)} edges · Solid: reported content · Dashed: interpretation or hypothesis")
        with right:
            chosen=st.session_state.get('ccr-selected',{})
            related=[x for x in selected_claims if x['claim_id']==chosen.get('claim_id') or entity_id(x['subject'],document)==chosen.get('id') or x['object'] and entity_id(x['object'],document)==chosen.get('id')]
            if related:
                by_id={record['claim_id']:record for record in related}
                selected_id=st.selectbox('Selected record',list(by_id),format_func=lambda id:by_id[id]['statement'][:90],key='graph-claim-'+chosen.get('id','none'))
                detail(by_id[selected_id],'graph-'+selected_id)
            else:
                st.markdown('#### Explore relations and evidence')
                st.write('Select a graph node or edge to inspect measurements, experimental conditions, and source evidence.')
                st.info('This is a source-backed development demo. Automated checks do not replace domain review.')
    else: st.info('Use Add / update to select a PDF and ontology profile, then run ingestion to browse the graph.')

with tabs[1]:
    if claims:
        records=[];items=[]
        for x in claims:
            if x['predicate'] not in ('hasDissolutionRate','hasEnhancementFactor'): continue
            cond={c['kind'].lower():c for c in x['conditions']}
            records.append({'Mineral':x['subject']['name'],'Measurement':x['predicate'],'pH':cond.get('ph',{}).get('value'),'Medium':cond.get('medium',{}).get('raw'),'Reported value':x['quantity']['raw'],'Value':x['quantity']['value'],'Unit':x['quantity']['unit'],'PDF pages':','.join(map(str,sorted({e['page'] for e in x['evidence_records']})))})
            items.append(x)
        st.markdown('#### Dissolution rates and enhancement factors')
        st.caption('Rates are calculated by the authors from Si release, surface area, and 120 min under a zero-order assumption. Enhancement factors preserve the reported values.')
        frame=pd.DataFrame(records)
        event=st.dataframe(frame,hide_index=True,width='stretch',on_select='rerun',selection_mode='single-row',column_config={'Value':st.column_config.NumberColumn(format='%.3e')},key='experiment-table')
        if st.button('Save experimental CSV to USB'):
            target=ROOT/'exports/Wang_Table3.csv';frame.to_csv(target,index=False,encoding='utf-8-sig');st.success('Saved: '+str(target))
        if event.selection.rows: detail(items[event.selection.rows[0]],'experiment')
        audit=ROOT/'runs'/run_id/'table3-audit.json'
        if audit.exists(): st.success(f"Table 3 independent numerical check: {read(audit)['passed']} / 42")

with tabs[2]:
    st.markdown('#### Add a paper and update the knowledge graph')
    uploaded=st.file_uploader('Paper PDF (leave empty to use the prepared Wang example)',type=['pdf'])
    config_choice=st.radio('Ontology profile',['Wang v0.1 development profile','Upload rules, vocabulary, and schema'],horizontal=True)
    active_profile=SOURCE/'profiles/wang-v0.1'
    profile_error=None
    if config_choice.startswith('Upload'):
        uploads=st.file_uploader('Upload all three: rules.md, vocabulary.json, output.schema.json',type=['md','json'],accept_multiple_files=True)
        if uploads:
            try: active_profile=Path(upload_profile({x.name:x.getvalue() for x in uploads})['path'])
            except Exception as error: profile_error=str(error);st.error(profile_error)
        else: profile_error='Upload the complete three-file profile.'
    with st.expander('View ontology definitions and rules'):
        ontology=active_profile/'ontology.md'
        if ontology.exists(): st.markdown(ontology.read_text())
        st.code((active_profile/'rules.md').read_text(),language='markdown')
    provider=st.selectbox('Extraction provider',['codex','vllm'],format_func=lambda x:'Codex on this Mac (existing sign-in)' if x=='codex' else 'CCR Qwen / vLLM (configured with environment variables)')
    force=st.checkbox('Force a new extraction and retain previous versions',value=False)
    if st.button('Add / update knowledge graph',type='primary',disabled=bool(profile_error)):
        path=next((ROOT/'inputs').glob('Wang*.pdf'),None)
        if path is None and document:
            path=Path(document['pdf'])
        if uploaded:
            from ccr_kg.config import digest
            path=ROOT/'inputs'/(digest(uploaded.getvalue())[:16]+'.pdf');path.write_bytes(uploaded.getvalue())
        if path is None or not path.exists():
            st.error('Select a PDF. No prepared Wang example is available in this workspace.')
            st.stop()
        id=time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'-ui'
        directory=ROOT/'runs'/id;directory.mkdir(parents=True,exist_ok=True)
        command=[str(ROOT/'runtime/venv/bin/python'),'-m','ccr_kg.cli','ingest',str(path),'--profile',str(active_profile),'--provider',provider,'--run-id',id]
        if force: command.append('--force')
        with (directory/'worker.log').open('w') as log:
            p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=os.environ.copy(),start_new_session=True)
        save(directory/'worker.json',{'pid':p.pid,'command':command,'created_at':time.time()})
        st.session_state['submitted-run']=id;st.success('Task submitted. Progress appears below. Refresh the graph after completion.')
    @st.fragment(run_every='5s')
    def progress():
        submitted=st.session_state.get('submitted-run')
        if submitted:
            log=ROOT/'runs'/submitted/'worker.log'
            if log.exists() and log.read_text().strip():
                content=log.read_text()
                result=content.strip().splitlines()[-1]
                completed=ROOT/'runs'/result/'run.json'
                if completed.exists() and read(completed).get('status')=='succeeded':
                    st.success('Completed: '+result+'. Identical inputs can reuse a completed result.')
                elif 'Traceback' in content:
                    st.error('Submission failed. The previous graph is retained. Worker log: '+str(log))
        paths=sorted((ROOT/'runs').glob('*/run.json'),key=lambda p:p.stat().st_mtime,reverse=True)
        if paths:
            item=read(paths[0]);st.write('Latest task: ',item['run_id'],' · ',item['status'],' · ',item.get('stage',''))
            if item.get('error'): st.error(item['error'])
            if item['status']=='running': st.progress(min((item.get('task_index',0)+.2)/max(item.get('task_count',1),1),.99))
    progress()

with tabs[3]:
    st.markdown('#### Human review and publication')
    st.caption('This demo does not automatically approve or publish records. Reviews retain the actual reviewer, rationale, and history.')
    if run_id:
        candidates=read(ROOT/'runs'/run_id/'candidates.validated.json')
        selected=st.selectbox('Candidate for review',range(len(candidates)),format_func=lambda i:candidates[i]['statement'][:100],key='review-claim')
        candidate=candidates[selected]
        st.write(candidate['statement']);st.json(candidate['validation'],expanded=False)
        reviewer=st.text_input('Actual reviewer name')
        note=st.text_area('Review rationale or outstanding questions')
        acknowledged=st.checkbox('I have checked the source evidence, conditions, and meaning of this record')
        buttons=st.columns(3)
        for col,label,decision in zip(buttons,['Accept','Reject','Defer'],['accepted','rejected','deferred']):
            if col.button(label,disabled=not reviewer.strip() or not acknowledged):
                try: review_claim(run_id,candidate['claim_id'],decision,reviewer,note);st.success('Review saved')
                except Exception as error:st.error(str(error))
        if st.button('Publish accepted records'):
            try: st.success(f'Published {publish_accepted(run_id)} reviewed records')
            except Exception as error:st.error(str(error))

with tabs[4]:
    paths=sorted((ROOT/'runs').glob('*/run.json'),key=lambda p:p.stat().st_mtime,reverse=True)
    for path in paths:
        item=read(path)
        with st.expander(item['run_id']+' · '+item['status']+' · '+item.get('stage','')):
            st.json(item)
            coverage=path.parent/'coverage.json'
            if coverage.exists(): st.dataframe(pd.DataFrame(read(coverage)),hide_index=True,width='stretch')
    st.caption('Original requests, model outputs, events, evidence, candidates, and validation reports are saved in the USB runs directory.')
