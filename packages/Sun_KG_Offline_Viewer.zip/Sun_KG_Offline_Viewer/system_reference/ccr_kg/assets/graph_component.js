export default function(component) {
 const {parentElement,data,setStateValue,setTriggerValue}=component;
 let host=parentElement.querySelector('.ccr-network');
 if(!host){host=document.createElement('div');host.className='ccr-network';host.style.cssText='position:relative;height:620px;width:100%;background:#f5f8fb;border:1px solid #d7e1e9;border-radius:12px;';parentElement.appendChild(host);}
 const colors={Mineral:'#497bb5',Sample:'#6a9ac3',Chemical:'#d77662',Element:'#65a481',StructuralClass:'#8c7ab1',StructuralConcept:'#9d88be',Process:'#dbac52',Surface:'#8c9eaa',Method:'#71a2a0',Property:'#c58aa4',Measurement:'#d9b86e'};
 const signature=JSON.stringify(data.elements);
 let cy=host.__cy;
 if(!cy){
  cy=globalThis.cytoscape({container:host,elements:data.elements,style:[
   {selector:'node',style:{'label':'data(label)','background-color':e=>colors[e.data('type')]||'#60879a','width':e=>e.data('type')==='Measurement'?30:48,'height':e=>e.data('type')==='Measurement'?30:48,'color':'#23374a','font-size':11,'text-wrap':'wrap','text-max-width':120,'text-valign':'bottom','text-margin-y':6,'border-width':2,'border-color':'#ffffff'}},
   {selector:'edge',style:{'width':1.4,'line-color':'#a9b7c7','target-arrow-color':'#a9b7c7','target-arrow-shape':'triangle','curve-style':'bezier','label':'data(label)','font-size':8,'color':'#64758a','text-background-color':'#f5f8fb','text-background-opacity':0.9,'text-background-padding':2}},
   {selector:'edge[?proposed]',style:{'line-style':'dashed','line-color':'#bd826a','target-arrow-color':'#bd826a'}},
   {selector:'node:selected',style:{'border-color':'#e26d47','border-width':4}},
   {selector:'edge:selected',style:{'line-color':'#e26d47','target-arrow-color':'#e26d47','width':3}},
  ],layout:{name:'cose',animate:false,randomize:false,nodeRepulsion:13000,idealEdgeLength:110,padding:45}});
  host.__cy=cy;host.__signature=signature;
 } else if(host.__signature!==signature){
  const positions={};cy.nodes().forEach(n=>positions[n.id()]=n.position());
  cy.elements().remove();cy.add(data.elements);cy.nodes().forEach(n=>{if(positions[n.id()])n.position(positions[n.id()]);});
  cy.layout({name:'cose',animate:false,randomize:false,nodeRepulsion:13000,idealEdgeLength:110,padding:45}).run();host.__signature=signature;
 }
 cy.off('tap'); cy.off('dbltap');
 cy.on('tap','node,edge',evt=>setStateValue('selected',{...evt.target.data()}));
 cy.on('dbltap','node',evt=>setTriggerValue('expand',evt.target.id()));
 cy.resize();
 let exportButton=host.querySelector('.ccr-export');
 if(!exportButton){exportButton=document.createElement('button');exportButton.className='ccr-export';exportButton.textContent='Save PNG to USB';exportButton.style.cssText='position:absolute;right:12px;top:12px;z-index:50;background:white;border:1px solid #ccd7e1;border-radius:7px;padding:8px 12px;color:#23374a;cursor:pointer;';host.appendChild(exportButton);}
 exportButton.onclick=evt=>{evt.stopPropagation();setTriggerValue('snapshot',cy.png({output:'base64uri',scale:1.5,bg:'#f5f8fb'}));};
 if(data.fit){cy.fit(undefined,40);}
 return ()=>{};
}
