CCR KG SYSTEM - OFFLINE VIEW OF THE SUN TEST RUN (REVISION 2)

Extract the whole ZIP and double-click Open_Sun_KG.html. No server, installation,
account, or network is required for browsing. Keep Sun_2023_original.pdf beside it.

This package is for team review of the shared KG system using its saved Sun run.
It retains the original interface structure, hardcoded wording, filtering rules,
graph colors, and default graph scope; it is not a Sun-specific redesigned demo.
All 98 nodes and 109 edges appear initially. Original node IDs and graph edges
are calculated with the exact saved system functions. Positions can differ.

The original five tabs remain. Graph search, drag/zoom, node/edge selection,
expansion, evidence text, PDF previews, and file downloads work locally.
Add/update and review/publication actions are disabled with explicit explanations.
History shows only this packaged run. Downloads use your browser, not the USB.

The source's Wang title,
measurement filters, and Experimental observation label are deliberately retained
as reviewable issues. Do not treat those inherited labels as Sun's study identity.

All original saved candidates, conditions, evidence, and pending/demo_only states
are unchanged. This package performs no new extraction or scientific approval.
The separate Sun_KG_Inputs_Outputs.zip preserves the original full I/O selection.
system_reference/ holds selected unchanged source files for inspection, not a
complete executable system.
See manifest.json and THIRD_PARTY_NOTICES.txt for integrity and attribution.
